import Vue from 'vue'
import VJstree from 'vue-jstree'

Vue.use(VJstree)
